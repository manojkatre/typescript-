//"3) create a class of Name Circle, and perform following opertion
//on the basis of radius of circle calculate how many time it is required spin to cover a given distance "
class Circle
{
	rad :number;
	Circumference:number;
	pi:number;
	distanc:number;
	times:number;
	
	constructor(rad:number,pi:number,distanc:number)
	{
		this.rad=rad;
		this.pi=pi;
		this.distanc=distanc;
	
	}
	disp()
	{
		this.Circumference= 2 *this.pi*this.rad;
		
			this.times=this.distanc/this.Circumference;
			
			console.log("Wheel rotation=" +this.times);
	}
}
let C=new Circle(14,22/7,2200);
C.disp();